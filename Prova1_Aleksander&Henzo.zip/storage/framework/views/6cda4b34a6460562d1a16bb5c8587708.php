<h1>
Funcionario    
<h1><?php /**PATH C:\Users\35517\Desktop\laravel\Prova1\resources\views/Funcionario.blade.php ENDPATH**/ ?>
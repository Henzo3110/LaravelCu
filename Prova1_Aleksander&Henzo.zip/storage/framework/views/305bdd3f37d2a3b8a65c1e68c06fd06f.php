<h3>
    Cargo: junior <br>
    Nome: <?php echo e($Junior->getNome()); ?> <br>
    Salario Aumentado Com Impostos: <?php echo e($Junior->getSalario()); ?> <br>
    Inscricao : <?php echo e($Junior-> getNumeroInscricao()); ?><br>
    
    
</h3><?php /**PATH C:\Users\35517\Desktop\laravel\Prova1\resources\views/JuniorImpostoAumentado.blade.php ENDPATH**/ ?>
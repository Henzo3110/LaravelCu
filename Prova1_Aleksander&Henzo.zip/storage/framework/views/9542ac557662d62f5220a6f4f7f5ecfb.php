<h3>
    
    Funcionario: <?php echo e($Junior->getNome()); ?> <br>
    Numero Inscrição : <?php echo e($Junior-> getNumeroInscricao()); ?><br>
    Cargo: junior <br>
    Salario: <?php echo e($Junior->getSalario()); ?> <br>
    <?php echo e($Junior->getHorasTrabalhadas()); ?> <br>
    Porcentagem de aumento de Salário : 10%<br>
    
</h3><?php /**PATH C:\Users\35517\Desktop\laravel\Prova1\resources\views/JuniorAumentado.blade.php ENDPATH**/ ?>
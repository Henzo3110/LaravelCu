<h3>
    Funcionario: <?php echo e($Pleno->getNome()); ?> <br>
    Numero Inscrição : <?php echo e($Pleno-> getNumeroInscricao()); ?><br>
    Cargo: Pleno <br>
    Salario: <?php echo e($Pleno->getSalario()); ?> <br>
    Porcentagem de aumento de Salário : 15%<br>
</h3><?php /**PATH C:\Users\35517\Desktop\laravel\Prova1\resources\views/PlenoAumentado.blade.php ENDPATH**/ ?>
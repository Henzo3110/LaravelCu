<h3>
    Funcionario: <?php echo e($Senior->getNome()); ?> <br>
    Numero Inscrição : <?php echo e($Senior-> getNumeroInscricao()); ?><br>
    Cargo: Senior <br>
    Salario: <?php echo e($Senior->getSalario()); ?> <br>
    Porcentagem de aumento de Salário : 20%<br>
</h3><?php /**PATH C:\Users\35517\Desktop\laravel\Prova1\resources\views/SeniorAumentado.blade.php ENDPATH**/ ?>
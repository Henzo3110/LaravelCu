<h3>
    Teste controller, view e model query param: {{ $param->getGet() }} <br>
    Teste controller, view e model path param inteiro: {{ $param->getPathInteiro() }} <br>
    Teste controller, view e model path param string: {{ $param->getPathString() }} <br>
</h3>
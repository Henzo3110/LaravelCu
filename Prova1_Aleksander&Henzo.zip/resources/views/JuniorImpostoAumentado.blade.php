<h3>
    Cargo: junior <br>
    Nome: {{ $Junior->getNome() }} <br>
    Salario Aumentado Com Impostos: {{ $Junior->getSalario() }} <br>
    Inscricao : {{$Junior-> getNumeroInscricao()}}<br>
    
    
</h3>
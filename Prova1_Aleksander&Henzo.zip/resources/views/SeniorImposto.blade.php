<h3>
    Funcionario: {{ $Senior->getNome() }} <br>
    Numero Inscrição : {{ $Senior-> getNumeroInscricao()}}<br>
    Cargo: Senior <br>
    Salario Com Imposto: {{ $Senior->getSalario() }} <br>
    Porcentagem de aumento de Salário : 20%<br>
</h3>
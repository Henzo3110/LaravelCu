<h3>
    Funcionario: {{ $Pleno->getNome() }} <br>
    Numero Inscrição : {{ $Pleno-> getNumeroInscricao()}}<br>
    Cargo: Pleno <br>
    Salario: {{ $Pleno->getSalario() }} <br>
    Porcentagem de aumento de Salário : 15%<br>
</h3>
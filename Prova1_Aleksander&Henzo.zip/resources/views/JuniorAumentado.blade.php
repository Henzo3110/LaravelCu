<h3>
    
    Funcionario: {{ $Junior->getNome() }} <br>
    Numero Inscrição : {{ $Junior-> getNumeroInscricao()}}<br>
    Cargo: junior <br>
    Salario: {{ $Junior->getSalario() }} <br>
    {{$Junior->getHorasTrabalhadas()}} <br>
    Porcentagem de aumento de Salário : 10%<br>
    
</h3>
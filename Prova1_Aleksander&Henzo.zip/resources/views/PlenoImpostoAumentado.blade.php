<h3>
Cargo: Pleno <br>
    Nome: {{ $Junior->getNome() }} <br>
    SalarioComImpostos: {{ $Junior->getSalario() }} <br>
    Inscricao : {{$Junior-> getNumeroInscricao()}}<br>
    
    
</h3>